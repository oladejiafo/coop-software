<?php
session_start();
//check to see if user has logged in with a valid password
if (!isset($_SESSION['USER_ID']) & ($_SESSION['access_lvl'] != 5))
{
$redirect = $_SERVER['PHP_SELF'];
header("Refresh: 0; URL=indexx.php?redirect=$redirect");

}

 require_once 'conn.php';
 require_once 'header.php';
 require_once 'style.php';

$ID=$_REQUEST['ID'];

$sql="SELECT `ID`,`Category` FROM `asset category` WHERE `Company` ='" .$_SESSION['company']. "' AND  `ID`='$ID'";
$result = mysqli_query($conn,$sql) or die('Could not look up user data; ' . mysqli_error());
$row = mysqli_fetch_array($result);
?>

<div align="center">
	<table border="0" width="80%" cellspacing="1" bgcolor="#FFFFFF" id="table1">

		<tr>
			<td>

<form action="submitcategory.php" method="post">
<p><b><font face="Verdana" color="green" style="font-size: 14pt"><u>Asset Category Update</u></font></b></p>

<div align="left">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="99%" id="table2" height="70">

    <tr>
      <td width="7%" height="28">
        <font face="Verdana" style="font-size: 9pt">Category:
      </font>
      </td>
      <td width="34%" height="28">
        <span style="font-size: 9pt">
        <input type="text" name="category" size="31" value="<?php echo $row['Category']; ?>">
        <input type="hidden" name="catid" size="31" value="<?php echo $row['ID']; ?>">
      	</span>
      </td>
      <td width="1%" height="28"></td>
     </tr>

  </table>
<br>
<?php
if (!$ID){
?>
  <input type="submit" value="Save" name="submit"> &nbsp;
<?php } 
 else { ?>
  <input type="submit" value="Update" name="submit"> &nbsp; 
  <input type="submit" value="Delete" name="submit"> &nbsp; 
<br>
<br>
<?php
} 
 echo "<a href='tableupdates.php'>Click here</a> to return.";

 require_once 'footr.php';
 require_once 'footer.php';
?>
 </td>
 </tr>
</table>

  </p>
  </div>
</body>
 
</form>
</td>
			</tr>
		</table>
		</div>

