<?php
//call.php
Var_dump($_POST);
?>