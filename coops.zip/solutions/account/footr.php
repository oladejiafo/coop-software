<body bgcolor="#D2DD8F">

<table border="0" style="border-collapse: collapse" bordercolor="#800000" width="100%" bgcolor="#006633">
  <tr>
    <td width="21%" bgcolor="#006633" align="left">
    <font face="Arial" size="2"> 
    <a style="text-decoration: none" target="main" href="javascript:;">
    <font color="#FFFFFF"></font></a></font></td>
    <td width="20%" bgcolor="#006633" align="center">
    <font face="Arial" size="2">
    <a style="text-decoration: none" target="main" href="javascript:;">
    <font color="#FFFFFF"></font></a></font></td>

    <td width="10%" bgcolor="#006633" align="left">
    <font color="#000080" face="Arial" size="2">
    <a style="text-decoration: none" target="main" href="javascript:;">
	<font color="#FFFFFF"></font></a></font></td>

    <td width="138%" bgcolor="#006633" align="right">
    <a target="_blank" href="http://www.waltergates.com"><font size="2" face="Arial" color="#E0B16C">(c) 2011-<?php echo date('Y'); ?> WALTERGATES - info@waltergates.com</font></a>
    </td>
  </tr>
</table>

</body>