<?php
define("EW_REPORT_TABLE_PREFIX", "||PHPReportMaker||", TRUE);
?>
