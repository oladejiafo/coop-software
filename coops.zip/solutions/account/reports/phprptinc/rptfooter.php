<?php if (@$sExport == "") { ?>
			<!-- right column (end) -->
		</td></tr>
	</table>
	<!-- content (end) -->
	<!-- footer (begin) --><!-- *** Note: Only licensed users are allowed to remove or change the following copyright statement. *** -->
	<div class="ewFooterRow">
		<div class="ewFooterText">&nbsp;&copy;2011 Waltergates. All rights reserved.</div>
		<!-- Place other links, for example, disclaimer, here -->
	</div>
	<!-- footer (end) -->	
</div>
<script type="text/javascript">
<!--
xGetElementsByClassName(EW_REPORT_TABLE_CLASS, null, "TABLE", ewrpt_SetupTable); // init the table

//-->
</script>
<?php } ?>
</body>
</html>
