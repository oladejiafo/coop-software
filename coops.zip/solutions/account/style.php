<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma, Arial, Helvetica, sans-serif;
	font-size: 14px;        
	color: #000000;
}
body {
	//background-image: url(images/5.gif);
}
a:link {
	color: #E0B16C;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #E0B16C;
}
a:hover {
	text-decoration: none;
	color: #696969;
}
a:active {
	text-decoration: none;
	color: #696969;
}
a {
	font-weight: bold;
}
-->
    </style>