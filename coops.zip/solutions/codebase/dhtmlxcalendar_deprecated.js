/*
Product Name: dhtmlxCalendar 
Version: 4.0.3 
Edition: Standard 
License: content of this file is covered by GPL. Usage outside GPL terms is prohibited. To obtain Commercial or Enterprise license contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

dhtmlXCalendarObject.prototype.draw=function(){this.show()};dhtmlXCalendarObject.prototype.close=function(){this.hide()};dhtmlXCalendarObject.prototype.setYearsRange=function(){};